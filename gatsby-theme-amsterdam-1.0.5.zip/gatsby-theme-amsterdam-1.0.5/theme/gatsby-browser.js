import scrollDelay from './src/gatsby/browser/shouldUpdateScroll'
import CustomLayout from './src/gatsby/browser/wrapPageElement'
export const wrapPageElement = CustomLayout
export const shouldUpdateScroll = scrollDelay
