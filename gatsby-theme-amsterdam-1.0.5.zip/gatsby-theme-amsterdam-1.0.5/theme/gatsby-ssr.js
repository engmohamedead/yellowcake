import CustomLayout from './src/gatsby/browser/wrapPageElement'
export const wrapPageElement = CustomLayout
